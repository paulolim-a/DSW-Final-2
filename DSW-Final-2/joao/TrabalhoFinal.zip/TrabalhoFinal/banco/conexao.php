<?php
$conexao = mysqli_connect('localhost','root','');
$db = mysqli_select_db($conexao,'projeto_final');
?>